package org.college;

public class College {

	public void collegeName()
	{
		System.out.println("College Name : SEC college");
	}
	public void collegeCode()
	{
		System.out.println("College Code : col123");
	}
	public void collegeRank()
	{
		System.out.println("College Rank : 1");
	}
}
