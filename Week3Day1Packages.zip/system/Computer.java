package org.system;

public class Computer {

	public void computerModel()
	{
		System.out.println("Inside computer model method");
	}

}
