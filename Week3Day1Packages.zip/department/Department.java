package org.department;
import org.college.*;

public class Department extends College {

	public void deptName()
	{
		System.out.println("Department Name : Computer Science and Engineering");
	}
}
